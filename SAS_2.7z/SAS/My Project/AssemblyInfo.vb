﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("School Admission System")> 
<Assembly: AssemblyDescription("A simple program that lets school administrators keep an easy to use digital copy of their students' information")> 
<Assembly: AssemblyCompany("Oliver Magweta")> 
<Assembly: AssemblyProduct("SAS")> 
<Assembly: AssemblyCopyright("Copyright Oliver Magweta ©  2015")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("7bff7ea1-4a0a-4c05-9552-cecde8e72a76")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
