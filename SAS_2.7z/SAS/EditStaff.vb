﻿Public Class EditStaff
    Dim stfID As Integer
    Dim stdDT As New SASTableAdapters.StaffTableAdapter
    Dim Alphabet As List(Of String) = New List(Of String)
    Dim NumberLine As List(Of String) = New List(Of String)

    Public Sub New(ByVal i As Integer)
        stfID = i
        ' This call is required by the designer.
        InitializeComponent()
        PopulateLists()

        ' Add any initialization after the InitializeComponent() call.
    End Sub
    Private Sub bnCancel_Click(sender As Object, e As EventArgs) Handles bnCancel.Click
        Close()
    End Sub


    Private Sub PopulateLists()
        Alphabet.Add("a")
        Alphabet.Add("b")
        Alphabet.Add("c")
        Alphabet.Add("d")
        Alphabet.Add("h")
        Alphabet.Add("e")
        Alphabet.Add("f")
        Alphabet.Add("g")
        Alphabet.Add("i")
        Alphabet.Add("j")
        Alphabet.Add("k")
        Alphabet.Add("l")
        Alphabet.Add("m")
        Alphabet.Add("n")
        Alphabet.Add("o")
        Alphabet.Add("p")
        Alphabet.Add("q")
        Alphabet.Add("r")
        Alphabet.Add("s")
        Alphabet.Add("t")
        Alphabet.Add("u")
        Alphabet.Add("v")
        Alphabet.Add("w")
        Alphabet.Add("z")
        Alphabet.Add("x")
        Alphabet.Add("y")
        Alphabet.Add("A")
        Alphabet.Add("B")
        Alphabet.Add("C")
        Alphabet.Add("D")
        Alphabet.Add("E")
        Alphabet.Add("F")
        Alphabet.Add("G")
        Alphabet.Add("H")
        Alphabet.Add("I")
        Alphabet.Add("J")
        Alphabet.Add("K")
        Alphabet.Add("L")
        Alphabet.Add("M")
        Alphabet.Add("N")
        Alphabet.Add("O")
        Alphabet.Add("P")
        Alphabet.Add("Q")
        Alphabet.Add("R")
        Alphabet.Add("S")
        Alphabet.Add("T")
        Alphabet.Add("U")
        Alphabet.Add("V")
        Alphabet.Add("W")
        Alphabet.Add("X")
        Alphabet.Add("Y")
        Alphabet.Add("Z")

        NumberLine.Add("0")
        NumberLine.Add("1")
        NumberLine.Add("2")
        NumberLine.Add("3")
        NumberLine.Add("4")
        NumberLine.Add("5")
        NumberLine.Add("6")
        NumberLine.Add("7")
        NumberLine.Add("8")
        NumberLine.Add("9")
    End Sub

    Private Sub bnStudents_Click(sender As Object, e As EventArgs) Handles bnStudents.Click
        Dim firstnameCheck As Boolean = True
        Dim lastnameCheck As Boolean = True
        Dim cellnocheck As Boolean = True

        If (txtCellno.Text = "" Or txtDesignation.Text = "" Or txtFirstName.Text = "" Or txtHomeAddress.Text = "" Or txtLastName.Text = "" Or txtNationalID.Text = "" Or cmGender.Text = "") Then
            MessageBox.Show("All fields are required. Please fill in all fields to continue", "Fill in all required fields")
        Else

            For Each i As String In Alphabet
                If (txtCellno.Text.Contains(i)) Then
                    cellnocheck = False
                End If
            Next

            For Each i As String In NumberLine
                If (txtFirstName.Text.Contains(i)) Then
                    firstnameCheck = False
                End If
            Next

            For Each i As String In NumberLine
                If (txtLastName.Text.Contains(i)) Then
                    lastnameCheck = False
                End If
            Next

            If (firstnameCheck = True And lastnameCheck = True And cellnocheck = True) Then
                stdDT.UpdateStaffByID(txtFirstName.Text, txtLastName.Text, txtNationalID.Text, txtCellno.Text, txtHomeAddress.Text, txtDesignation.Text, cmGender.Text, stfID)
                MessageBox.Show("Staff member information updated successfully!")
            Else
                MessageBox.Show("You have entered an invalid character in one of the textboxes. Please correct the errors and try again")
            End If

        End If
    End Sub
End Class