﻿Public Class frmViewStudent

    Dim stdTA As New SASTableAdapters.StudentsTableAdapter
    Private Sub frmViewStudent_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SAS1.Students' table. You can move, or remove it, as needed.
        Me.StudentsTableAdapter1.Fill(Me.SAS1.Students)

    End Sub
    Private Sub txtQuery_TextChanged(sender As Object, e As EventArgs) Handles txtQuery.TextChanged
        Dim Query_LastName As String = ""
        Dim Query_ID As Integer

        If (txtQuery.Text = "") Then
            Me.StudentsTableAdapter1.Fill(Me.SAS1.Students)
        Else
            If (rbLastName.Checked = True) Then
                Query_LastName = txtQuery.Text + "%"

                Try
                    Me.StudentsTableAdapter1.SearchByLastName(Me.SAS1.Students, Query_LastName)
                Catch ex As Exception
                    MessageBox.Show("An error occured while attempting to query the database", "Database error", MessageBoxButtons.OK)
                End Try

            ElseIf (rbID.Checked = True)

                If (Integer.TryParse(txtQuery.Text, Query_ID)) Then

                    Try
                        Me.StudentsTableAdapter.SearchByID(Me.SAS1.Students, Query_ID)
                    Catch ex As System.Exception
                        System.Windows.Forms.MessageBox.Show(ex.Message)
                    End Try

                Else
                    MessageBox.Show("ID can only be a number. Please input a number and try again")
                    txtQuery.Text = ""
                End If
            End If

        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub rbID_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbID.CheckedChanged

    End Sub

    Private Sub rbLastName_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbLastName.CheckedChanged

    End Sub

    Private Sub bnClode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles bnClode.Click
        Close()
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If (DataGridView1.SelectedRows.Count <= 0) Then
            MessageBox.Show("No student selected")

        ElseIf (DataGridView1.SelectedRows.Count = 1) Then
            Dim res As Windows.Forms.DialogResult

            res = MessageBox.Show("Are you sure you want to delete the selected student?" + vbNewLine, "Confirm action !", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If (res = DialogResult.Yes) Then
                stdTA.DeleteStudentByID(Convert.ToInt32(DataGridView1.SelectedRows.Item(0).Cells.Item(0).Value))
                Me.StudentsTableAdapter1.Fill(Me.SAS1.Students)
                MessageBox.Show("Student deleted successfully...")
            Else
                'Do nothing
            End If
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If (DataGridView1.SelectedRows.Count <= 0) Then
            MessageBox.Show("No student selected")

        ElseIf (DataGridView1.SelectedRows.Count = 1) Then
            Dim StdID As Integer = Convert.ToInt32(DataGridView1.SelectedRows.Item(0).Cells.Item(0).Value)
            Dim a As New EditStudent(StdID)

            a.Show()

        End If
    End Sub
End Class