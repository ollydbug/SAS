﻿Imports System.Data.OleDb

Public Class frmLogin

    Dim userTB As New SASTableAdapters.UsersTableAdapter

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click

        If (UsernameTextBox.Text = "" Or PasswordTextBox.Text = "") Then
            MessageBox.Show("Username and password are both required", "Fill in all required fields", MessageBoxButtons.OK)

        Else


            If (UsernameTextBox.Text IsNot "" And PasswordTextBox IsNot "") Then
                Try


                    If (userTB.CheckUser(UsernameTextBox.Text, PasswordTextBox.Text) <= 0) Then
                        MessageBox.Show("Username and password could not match any of our records. Please try again", "Authentication error!")
                        PasswordTextBox.Text = ""
                        UsernameTextBox.Text = ""

                        UsernameTextBox.Focus()
                    Else
                        frmMain.Show()
                        Close()
                    End If


                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                    'MessageBox.Show("Failed to connect to database", "Database connection error")
                End Try
            End If
        End If
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Application.Exit()
    End Sub

    Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


    End Sub

    Private Sub PasswordTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasswordTextBox.TextChanged
    End Sub
End Class
