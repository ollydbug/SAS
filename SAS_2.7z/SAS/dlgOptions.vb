﻿Imports SAS.My.MySettings

Public Class dlgOptions

    Private Sub dlgOptions_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub bnCancel_Click(sender As Object, e As EventArgs) Handles bnCancel.Click
        Close()
    End Sub

    Private Sub bnSave_Click(sender As Object, e As EventArgs) Handles bnSave.Click


        If (txtRefreshTIme.Text IsNot "" And txtSchoolName.Text IsNot "" And cmSchoolType.Text IsNot "") Then

            If (My.MySettings.Default.SchoolName IsNot txtSchoolName.Text And My.MySettings.Default.SchoolType IsNot cmSchoolType.Text) Then


                My.MySettings.Default.SchoolName = txtSchoolName.Text
                My.MySettings.Default.SchoolType = cmSchoolType.Text
                My.MySettings.Default.CountdownTime = Convert.ToInt32(txtRefreshTIme.Text)

                My.MySettings.Default.Save()

                MessageBox.Show("Settings saved successfully", "Success")

                txtSchoolName.Text = ""
                cmSchoolType.SelectedIndex = 0

            End If

        End If
    End Sub
End Class