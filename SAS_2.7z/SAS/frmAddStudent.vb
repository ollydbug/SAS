﻿Imports System
Imports System.Data
Imports System.Data.OleDb

Public Class frmAddStudent
    Dim sasDT As New SAS.StudentsDataTable
    Dim stdDT As New SASTableAdapters.StudentsTableAdapter
    Dim Alphabet As List(Of String) = New List(Of String)
    Dim NumberLine As List(Of String) = New List(Of String)

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmGender.SelectedIndexChanged

    End Sub

    Private Sub frmAddStudent_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        Alphabet.Add("a")
        Alphabet.Add("b")
        Alphabet.Add("c")
        Alphabet.Add("d")
        Alphabet.Add("h")
        Alphabet.Add("e")
        Alphabet.Add("f")
        Alphabet.Add("g")
        Alphabet.Add("i")
        Alphabet.Add("j")
        Alphabet.Add("k")
        Alphabet.Add("l")
        Alphabet.Add("m")
        Alphabet.Add("n")
        Alphabet.Add("o")
        Alphabet.Add("p")
        Alphabet.Add("q")
        Alphabet.Add("r")
        Alphabet.Add("s")
        Alphabet.Add("t")
        Alphabet.Add("u")
        Alphabet.Add("v")
        Alphabet.Add("w")
        Alphabet.Add("z")
        Alphabet.Add("x")
        Alphabet.Add("y")
        Alphabet.Add("A")
        Alphabet.Add("B")
        Alphabet.Add("C")
        Alphabet.Add("D")
        Alphabet.Add("E")
        Alphabet.Add("F")
        Alphabet.Add("G")
        Alphabet.Add("H")
        Alphabet.Add("I")
        Alphabet.Add("J")
        Alphabet.Add("K")
        Alphabet.Add("L")
        Alphabet.Add("M")
        Alphabet.Add("N")
        Alphabet.Add("O")
        Alphabet.Add("P")
        Alphabet.Add("Q")
        Alphabet.Add("R")
        Alphabet.Add("S")
        Alphabet.Add("T")
        Alphabet.Add("U")
        Alphabet.Add("V")
        Alphabet.Add("W")
        Alphabet.Add("X")
        Alphabet.Add("Y")
        Alphabet.Add("Z")

        NumberLine.Add("0")
        NumberLine.Add("1")
        NumberLine.Add("2")
        NumberLine.Add("3")
        NumberLine.Add("4")
        NumberLine.Add("5")
        NumberLine.Add("6")
        NumberLine.Add("7")
        NumberLine.Add("8")
        NumberLine.Add("9")

        cmGender.SelectedItem = cmGender.Items.Item(0)
        cmStream.SelectedItem = cmStream.Items.Item(0)
    End Sub

    Private Sub bnStudents_Click(sender As Object, e As EventArgs) Handles bnStudents.Click
        Dim firstnameCheck As Boolean = True
        Dim lastnameCheck As Boolean = True
        Dim cellnocheck As Boolean = True

        If (txtFirstName.Text = "" Or txtgCellno.Text = "" Or txtHomeAddress.Text = "" Or txtLastName.Text = "" Or cmGender.SelectedIndex <= -1) Then
            MessageBox.Show("All fields are required. Please fill in all fields to continue", "Fill in all required fields")

        Else
            For Each i As String In Alphabet
                If (txtgCellno.Text.Contains(i)) Then
                    cellnocheck = False
                End If
            Next

            For Each i As String In NumberLine
                If (txtFirstName.Text.Contains(i)) Then
                    firstnameCheck = False
                End If
            Next

            For Each i As String In NumberLine
                If (txtLastName.Text.Contains(i)) Then
                    lastnameCheck = False
                End If
            Next


            If (firstnameCheck = True And lastnameCheck = True And cellnocheck = True) Then
                Try
                    stdDT.AddNewStudent(txtFirstName.Text, txtLastName.Text, cmGender.Text, txtgCellno.Text, txtHomeAddress.Text, ComboBox2.Text, cmStream.Text)
                    sasDT.AcceptChanges()
                    MessageBox.Show("Student information recorded successfully", "Student recorded!")
                    txtFirstName.Text = ""
                    txtgCellno.Text = ""
                    txtHomeAddress.Text = ""
                    txtLastName.Text = ""
                    cmGender.Text = ""
                    cmStream.Text = ""
                    ComboBox2.Text = ""
                Catch ex As Exception
                    MessageBox.Show(ex.Message.ToString(), "An error occured")
                End Try
            Else
                MessageBox.Show("You have entered an invalid character in one of the textboxes. Please correct the errors and try again")
            End If

            If (txtFirstName.Text IsNot "" And txtgCellno.Text IsNot "" And txtHomeAddress.Text IsNot "" And txtLastName.Text IsNot "" And cmGender.SelectedIndex >= 0) Then

            End If
        End If
    End Sub

    Private Sub ComboBox2_DropDown(sender As Object, e As EventArgs) Handles ComboBox2.DropDown
        Dim i As Integer = 0
        Dim io As Boolean = False
        ComboBox2.Items.Clear()

        Try
            i = Convert.ToInt32(cmStream.Text)
            io = True
        Catch ex As Exception
            io = False
        End Try

        If (io) Then
            If (cmStream.Text > 4) Then
                ComboBox2.AllowDrop = True
                ComboBox2.Items.Add("Arts")
                ComboBox2.Items.Add("Commercials")

            ElseIf (cmStream.Text = "")
                ComboBox2.Items.Clear()

            Else
                ComboBox2.Items.Add("A")
                ComboBox2.Items.Add("B")
                ComboBox2.Items.Add("C")
                ComboBox2.Items.Add("D")
            End If
        End If

    End Sub

    Private Sub cmStream_DropDown(sender As Object, e As EventArgs) Handles cmStream.DropDown
        ComboBox2.Text = ""
    End Sub

    Private Sub bnCancel_Click(sender As Object, e As EventArgs) Handles bnCancel.Click
        Close()
    End Sub

    Private Sub cmStream_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmStream.SelectedIndexChanged
        ComboBox2.Items.Clear()
    End Sub
End Class