﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditStudent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmClass = New System.Windows.Forms.ComboBox()
        Me.cmStream = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtgCellno = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.cmGender = New System.Windows.Forms.ComboBox()
        Me.txtHomeAddress = New System.Windows.Forms.TextBox()
        Me.bnCancel = New System.Windows.Forms.Button()
        Me.bnStudents = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.SuspendLayout()
        '
        'cmClass
        '
        Me.cmClass.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmClass.FormattingEnabled = True
        Me.cmClass.Location = New System.Drawing.Point(177, 123)
        Me.cmClass.Name = "cmClass"
        Me.cmClass.Size = New System.Drawing.Size(57, 21)
        Me.cmClass.TabIndex = 46
        '
        'cmStream
        '
        Me.cmStream.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmStream.FormattingEnabled = True
        Me.cmStream.Items.AddRange(New Object() {"1", "2", "3", "4", "5", "6"})
        Me.cmStream.Location = New System.Drawing.Point(92, 123)
        Me.cmStream.Name = "cmStream"
        Me.cmStream.Size = New System.Drawing.Size(57, 21)
        Me.cmStream.TabIndex = 45
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(17, 126)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 44
        Me.Label6.Text = "Class:"
        '
        'txtgCellno
        '
        Me.txtgCellno.Location = New System.Drawing.Point(370, 71)
        Me.txtgCellno.Name = "txtgCellno"
        Me.txtgCellno.Size = New System.Drawing.Size(142, 20)
        Me.txtgCellno.TabIndex = 43
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(370, 29)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(142, 20)
        Me.txtLastName.TabIndex = 42
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(92, 26)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(142, 20)
        Me.txtFirstName.TabIndex = 41
        '
        'cmGender
        '
        Me.cmGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmGender.FormattingEnabled = True
        Me.cmGender.Items.AddRange(New Object() {"Female", "Male"})
        Me.cmGender.Location = New System.Drawing.Point(92, 71)
        Me.cmGender.Name = "cmGender"
        Me.cmGender.Size = New System.Drawing.Size(142, 21)
        Me.cmGender.TabIndex = 40
        '
        'txtHomeAddress
        '
        Me.txtHomeAddress.Location = New System.Drawing.Point(370, 123)
        Me.txtHomeAddress.Multiline = True
        Me.txtHomeAddress.Name = "txtHomeAddress"
        Me.txtHomeAddress.Size = New System.Drawing.Size(142, 54)
        Me.txtHomeAddress.TabIndex = 39
        '
        'bnCancel
        '
        Me.bnCancel.Location = New System.Drawing.Point(308, 214)
        Me.bnCancel.Name = "bnCancel"
        Me.bnCancel.Size = New System.Drawing.Size(124, 39)
        Me.bnCancel.TabIndex = 38
        Me.bnCancel.Text = "Cancel"
        Me.bnCancel.UseVisualStyleBackColor = True
        '
        'bnStudents
        '
        Me.bnStudents.Location = New System.Drawing.Point(92, 214)
        Me.bnStudents.Name = "bnStudents"
        Me.bnStudents.Size = New System.Drawing.Size(124, 39)
        Me.bnStudents.TabIndex = 37
        Me.bnStudents.Text = "Update"
        Me.bnStudents.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(266, 74)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(90, 13)
        Me.Label5.TabIndex = 36
        Me.Label5.Text = "Guardian Cell No." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(268, 126)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(79, 13)
        Me.Label4.TabIndex = 35
        Me.Label4.Text = "Home Address:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(15, 74)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(45, 13)
        Me.Label3.TabIndex = 34
        Me.Label3.Text = "Gender:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(266, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 33
        Me.Label2.Text = "Last Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(15, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 13)
        Me.Label1.TabIndex = 32
        Me.Label1.Text = "First Name(s):"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(17, 178)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(36, 13)
        Me.Label7.TabIndex = 47
        Me.Label7.Text = "D.O.B"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(92, 178)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(147, 20)
        Me.DateTimePicker1.TabIndex = 48
        '
        'EditStudent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(525, 265)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.cmClass)
        Me.Controls.Add(Me.cmStream)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtgCellno)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.cmGender)
        Me.Controls.Add(Me.txtHomeAddress)
        Me.Controls.Add(Me.bnCancel)
        Me.Controls.Add(Me.bnStudents)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(541, 304)
        Me.MinimumSize = New System.Drawing.Size(541, 304)
        Me.Name = "EditStudent"
        Me.Text = "Edit Student"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmClass As System.Windows.Forms.ComboBox
    Friend WithEvents cmStream As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtgCellno As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents cmGender As System.Windows.Forms.ComboBox
    Friend WithEvents txtHomeAddress As System.Windows.Forms.TextBox
    Friend WithEvents bnCancel As System.Windows.Forms.Button
    Friend WithEvents bnStudents As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
End Class
