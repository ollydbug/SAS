﻿Public Class frmViewStaff
    Dim stfTA As New SASTableAdapters.StaffTableAdapter
    Private Sub frmViewStaff_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'SAS1.Staff' table. You can move, or remove it, as needed.
        Me.StaffTableAdapter1.Fill(Me.SAS1.Staff)
        'TODO: This line of code loads data into the 'SAS.Staff' table. You can move, or remove it, as needed.


    End Sub

    Private Sub txtQuery_TextChanged(sender As Object, e As EventArgs) Handles txtQuery.TextChanged
        Dim Query_LastName As String = ""
        Dim Query_ID As Integer

        If (txtQuery.Text = "") Then
            ErrorProvider2.Clear()
            Me.StaffTableAdapter1.Fill(Me.SAS1.Staff)
        Else
            If (rbLastName.Checked = True) Then
                Query_LastName = txtQuery.Text + "%"

                Try
                    Me.StaffTableAdapter1.SearchByLastName(Me.SAS1.Staff, Query_LastName)
                Catch ex As Exception
                    MessageBox.Show("An error occured while attempting to query the database", "Database error", MessageBoxButtons.OK)
                End Try

            ElseIf (rbID.Checked = True)

                If (Integer.TryParse(txtQuery.Text, Query_ID)) Then

                    Try
                        Me.StaffTableAdapter1.SearchByID(Me.SAS1.Staff, Query_ID)
                    Catch ex As System.Exception
                        System.Windows.Forms.MessageBox.Show(ex.Message)
                    End Try

                Else
                    ErrorProvider2.SetError(txtQuery, "ID can only be a number. Please input a number and try again")

                    txtQuery.Text = ""
                End If
            End If

        End If
    End Sub

    Private Sub SearchByIDToolStripButton_Click(sender As Object, e As EventArgs)


    End Sub

    Private Sub StaffBindingSource_CurrentChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StaffBindingSource.CurrentChanged

    End Sub

    Private Sub rbID_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbID.CheckedChanged

    End Sub

    Private Sub DataGridView1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub rbLastName_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbLastName.CheckedChanged

    End Sub

    Private Sub bnClode_Click(sender As Object, e As EventArgs) Handles bnClode.Click
        Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (DataGridView1.SelectedRows.Count <= 0) Then
            MessageBox.Show("No staff member selected")

        ElseIf (DataGridView1.SelectedRows.Count = 1) Then
            Dim res As Windows.Forms.DialogResult

            res = MessageBox.Show("Are you sure you want to delete the selected staff member?" + vbNewLine, "Confirm action !", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If (res = DialogResult.Yes) Then
                stfTA.DeleteStaffByID(Convert.ToInt32(DataGridView1.SelectedRows.Item(0).Cells.Item(0).Value))
                Me.StaffTableAdapter1.Fill(Me.SAS1.Staff)
                MessageBox.Show("Staff member deleted successfully...")
            Else
                'Do nothing
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If (DataGridView1.SelectedRows.Count <= 0) Then
            MessageBox.Show("No staff member selected")

        ElseIf (DataGridView1.SelectedRows.Count = 1) Then
            Dim stfID As Integer = Convert.ToInt32(DataGridView1.SelectedRows.Item(0).Cells.Item(0).Value)
            Dim a As New EditStaff(stfID)

            a.Show()

        End If
    End Sub
End Class