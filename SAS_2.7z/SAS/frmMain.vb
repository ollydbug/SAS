﻿Imports System.Windows.Forms
Imports SAS.My.MySettings

Public Class frmMain
    Dim iCountdown As Integer = My.MySettings.Default.CountdownTime
    Dim timenow As DateTime
    Dim stdDT As New SASTableAdapters.StudentsTableAdapter
    Dim stfDT As New SASTableAdapters.StaffTableAdapter

    Private Sub ShowNewForm(ByVal sender As Object, ByVal e As EventArgs) Handles NewToolStripMenuItem.Click, NewToolStripButton.Click
        frmAddStudent.MdiParent = Me
        frmAddStudent.Show()
    End Sub

    Private Sub OpenFile(ByVal sender As Object, ByVal e As EventArgs)
        Dim OpenFileDialog As New OpenFileDialog
        OpenFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
        OpenFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
        If (OpenFileDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK) Then
            Dim FileName As String = OpenFileDialog.FileName
            ' TODO: Add code here to open the file.
        End If
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim SaveFileDialog As New SaveFileDialog
        SaveFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
        SaveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"

        If (SaveFileDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK) Then
            Dim FileName As String = SaveFileDialog.FileName
            ' TODO: Add code here to save the current contents of the form to a file.
        End If
    End Sub


    Private Sub ExitToolsStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Use My.Computer.Clipboard to insert the selected text or images into the clipboard
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Use My.Computer.Clipboard to insert the selected text or images into the clipboard
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        'Use My.Computer.Clipboard.GetText() or My.Computer.Clipboard.GetData to retrieve information from the clipboard.
    End Sub

    Private Sub ToolBarToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ToolBarToolStripMenuItem.Click
        Me.ToolStrip.Visible = Me.ToolBarToolStripMenuItem.Checked
    End Sub

    Private Sub StatusBarToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles StatusBarToolStripMenuItem.Click
        Me.StatusStrip.Visible = Me.StatusBarToolStripMenuItem.Checked
    End Sub

    Private Sub CascadeToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub TileVerticalToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub TileHorizontalToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub ArrangeIconsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.ArrangeIcons)
    End Sub

    Private Sub CloseAllToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles CloseAllToolStripMenuItem.Click
        ' Close all child forms of the parent.
        For Each ChildForm As Form In Me.MdiChildren
            ChildForm.Close()
        Next
    End Sub

    Private m_ChildFormNumber As Integer

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        frmAbout.Show()
    End Sub


    Private Sub OptionsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles OptionsToolStripMenuItem.Click
        dlgOptions.MdiParent = Me
        dlgOptions.Show()
    End Sub

    Private Sub tmrSexCount_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles tmrSexCount.Tick
        timenow = DateTime.Now
        ToolStripStatusLabel.Text = timenow.ToString("ddd d MMM yyyy       HH:MM:ss")


        iCountdown -= 1

        If (iCountdown = 0) Then
            lblBoysCount.Text = Convert.ToString(stdDT.ScalarQueryMalesCount)
            lblGirlsCount.Text = Convert.ToString(stdDT.ScalarQueryFemalesCount)
            lblTotalStudents.Text = Convert.ToString(stdDT.ScalarQueryTotalStudents)
            lblmaleCount.Text = Convert.ToString(stfDT.CountMaleStaff())
            lblfemalesCount.Text = Convert.ToString(stfDT.FemaleStaff())
            lblTotalStuff.Text = Convert.ToString(stfDT.TotalStaff())

            iCountdown = My.MySettings.Default.CountdownTime

        End If

    End Sub

    Private Sub frmMain_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        PictureBox2_Click(sender, e)
        lblSchoolName.Text = My.MySettings.Default.SchoolName
        lblBoysCount.Text = Convert.ToString(stdDT.ScalarQueryMalesCount)
        lblGirlsCount.Text = Convert.ToString(stdDT.ScalarQueryFemalesCount)
        lblTotalStudents.Text = Convert.ToString(stdDT.ScalarQueryTotalStudents)
        lblmaleCount.Text = Convert.ToString(stfDT.CountMaleStaff())
        lblfemalesCount.Text = Convert.ToString(stfDT.FemaleStaff())
        lblTotalStuff.Text = Convert.ToString(stfDT.TotalStaff())

    End Sub

    Private Sub frmMain_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing

    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bnAddStaff.Click
        frmAddStaff.MdiParent = Me
        frmAddStaff.Show()
    End Sub

    Private Sub PictureBox2_Click(ByVal sender As Object, ByVal e As EventArgs) Handles PictureBox2.Click
        Panel1.Hide()
        Panel2.Show()
    End Sub

    Private Sub PictureBox1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles PictureBox1.Click
        Panel2.Hide()
        Panel1.Show()
    End Sub

    Private Sub PictureBox1_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles PictureBox1.MouseEnter
        PictureBox1.BorderStyle = BorderStyle.Fixed3D
    End Sub

    Private Sub PictureBox1_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles PictureBox1.MouseLeave
        PictureBox1.BorderStyle = BorderStyle.None
    End Sub

    Private Sub PictureBox2_MouseEnter(ByVal sender As Object, ByVal e As EventArgs) Handles PictureBox2.MouseEnter
        PictureBox2.BorderStyle = BorderStyle.Fixed3D
    End Sub

    Private Sub PictureBox2_MouseLeave(ByVal sender As Object, ByVal e As EventArgs) Handles PictureBox2.MouseLeave
        PictureBox2.BorderStyle = BorderStyle.None
    End Sub

    Private Sub bnViewStudents_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bnViewStudents.Click
        frmViewStudent.MdiParent = Me
        frmViewStudent.Show()
    End Sub

    Private Sub bnViewStaff_Click(ByVal sender As Object, ByVal e As EventArgs) Handles bnViewStaff.Click
        frmViewStaff.MdiParent = Me
        frmViewStaff.Show()
    End Sub

    Private Sub ToolStripMenuItem1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles ToolStripMenuItem1.Click
        frmAddStaff.MdiParent = Me
        frmAddStaff.Show()
    End Sub

    Private Sub StaffListingToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles StaffListingToolStripMenuItem.Click
        frmViewStaff.MdiParent = Me
        frmViewStaff.Show()
    End Sub

    Private Sub StudentListingToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs) Handles StudentListingToolStripMenuItem.Click
        frmViewStudent.MdiParent = Me
        frmViewStudent.Show()
    End Sub


    Private Sub FileMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileMenu.Click

    End Sub
End Class

