﻿Public Class EditStudent
    Dim stdDT As New SASTableAdapters.StudentsTableAdapter
    Dim StdID As Integer
    Dim stdInfo As DataTable
    Dim Alphabet As List(Of String) = New List(Of String)
    Dim NumberLine As List(Of String) = New List(Of String)
    Public Sub New(ByVal i As Integer)
        StdID = i
        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub
    Private Sub EditStudent_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        stdInfo = stdDT.GetStudentInfoID(StdID)


        Dim FirstName As String = stdInfo.Rows.Item(0).Item(stdInfo.Columns.IndexOf("FirstName"))
        Dim LastName As String = stdInfo.Rows.Item(0).Item(stdInfo.Columns.IndexOf("LastName"))
        Dim Gender As String = stdInfo.Rows.Item(0).Item(stdInfo.Columns.IndexOf("Gender"))
        Dim GuardianCell As String = stdInfo.Rows.Item(0).Item(stdInfo.Columns.IndexOf("GuardianCell"))
        Dim HomeAddress As String = stdInfo.Rows.Item(0).Item(stdInfo.Columns.IndexOf("HomeAddress"))
        Dim Stream As String = stdInfo.Rows.Item(0).Item(stdInfo.Columns.IndexOf("Stream"))
        Dim _Class As String = stdInfo.Rows.Item(0).Item(stdInfo.Columns.IndexOf("Class"))

        txtFirstName.Text = FirstName
        txtgCellno.Text = GuardianCell
        txtHomeAddress.Text = HomeAddress
        txtLastName.Text = LastName
        cmClass.Text = _Class
        cmStream.Text = Stream
        cmGender.Text = Gender

        MdiParent = frmMain
    End Sub

    Private Sub bnStudents_Click(sender As Object, e As EventArgs) Handles bnStudents.Click
        Dim firstnameCheck As Boolean = True
        Dim lastnameCheck As Boolean = True
        Dim cellnocheck As Boolean = True

        If (txtFirstName.Text = "" Or txtgCellno.Text = "" Or txtHomeAddress.Text = "" Or txtLastName.Text = "" Or cmGender.SelectedIndex <= -1) Then
            MessageBox.Show("All fields are required. Please fill in all fields to continue", "Fill in all required fields")

        Else
            For Each i As String In Alphabet
                If (txtgCellno.Text.Contains(i)) Then
                    cellnocheck = False
                End If
            Next

            For Each i As String In NumberLine
                If (txtFirstName.Text.Contains(i)) Then
                    firstnameCheck = False
                End If
            Next

            For Each i As String In NumberLine
                If (txtLastName.Text.Contains(i)) Then
                    lastnameCheck = False
                End If
            Next


            If (firstnameCheck = True And lastnameCheck = True And cellnocheck = True) Then
                Try
                    stdDT.UpdateStudentInfomation(txtFirstName.Text, txtLastName.Text, cmGender.Text, txtgCellno.Text, txtHomeAddress.Text, cmClass.Text, cmStream.Text, StdID)
                    MessageBox.Show("Student information updated successfully", "Student recorded!")
                    txtFirstName.Text = ""
                    txtgCellno.Text = ""
                    txtHomeAddress.Text = ""
                    txtLastName.Text = ""
                    cmGender.Text = ""
                    cmStream.Text = ""
                    cmGender.Text = ""
                Catch ex As Exception
                    MessageBox.Show(ex.Message.ToString(), "An error occured")
                End Try
            Else
                MessageBox.Show("You have entered an invalid character in one of the textboxes. Please correct the errors and try again")
            End If

            If (txtFirstName.Text IsNot "" And txtgCellno.Text IsNot "" And txtHomeAddress.Text IsNot "" And txtLastName.Text IsNot "" And cmGender.SelectedIndex >= 0) Then

            End If
        End If
    End Sub

    Private Sub bnCancel_Click(sender As Object, e As EventArgs) Handles bnCancel.Click
        Close()
    End Sub


    Private Sub UpdateLits()
        Alphabet.Add("a")
        Alphabet.Add("b")
        Alphabet.Add("c")
        Alphabet.Add("d")
        Alphabet.Add("h")
        Alphabet.Add("e")
        Alphabet.Add("f")
        Alphabet.Add("g")
        Alphabet.Add("i")
        Alphabet.Add("j")
        Alphabet.Add("k")
        Alphabet.Add("l")
        Alphabet.Add("m")
        Alphabet.Add("n")
        Alphabet.Add("o")
        Alphabet.Add("p")
        Alphabet.Add("q")
        Alphabet.Add("r")
        Alphabet.Add("s")
        Alphabet.Add("t")
        Alphabet.Add("u")
        Alphabet.Add("v")
        Alphabet.Add("w")
        Alphabet.Add("z")
        Alphabet.Add("x")
        Alphabet.Add("y")
        Alphabet.Add("A")
        Alphabet.Add("B")
        Alphabet.Add("C")
        Alphabet.Add("D")
        Alphabet.Add("E")
        Alphabet.Add("F")
        Alphabet.Add("G")
        Alphabet.Add("H")
        Alphabet.Add("I")
        Alphabet.Add("J")
        Alphabet.Add("K")
        Alphabet.Add("L")
        Alphabet.Add("M")
        Alphabet.Add("N")
        Alphabet.Add("O")
        Alphabet.Add("P")
        Alphabet.Add("Q")
        Alphabet.Add("R")
        Alphabet.Add("S")
        Alphabet.Add("T")
        Alphabet.Add("U")
        Alphabet.Add("V")
        Alphabet.Add("W")
        Alphabet.Add("X")
        Alphabet.Add("Y")
        Alphabet.Add("Z")

        NumberLine.Add("0")
        NumberLine.Add("1")
        NumberLine.Add("2")
        NumberLine.Add("3")
        NumberLine.Add("4")
        NumberLine.Add("5")
        NumberLine.Add("6")
        NumberLine.Add("7")
        NumberLine.Add("8")
        NumberLine.Add("9")
    End Sub
End Class